/** Automatically generated file. DO NOT MODIFY */
package com.thanhgiong.member;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}